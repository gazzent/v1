from cybervpn import *

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
	async def create_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Quota:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
#jumlah ip

		async with bot.conversation(chat) as ip:
			await event.respond("**Choose ip limit**",buttons=[
[Button.inline(" 1 IP ","1"),
Button.inline(" 2 IP ","2")],
[Button.inline(" 3 IP ","3"),
Button.inline(" 6 IP ","6")]])
			ip = ip.wait_event(events.CallbackQuery)
			ip = (await ip).data.decode("ascii")

		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | addtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			domain = re.search("@(.*?):",b[0]).group(1)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
╔════╗
║╔╗╔╗║───╔╗
╚╝║║╠╩╦══╬╬══╦═╗
──║║║╔╣╔╗╠╣╔╗║╔╗╗
──║║║║║╚╝║║╔╗║║║║
──╚╝╚╝╚══╣╠╝╚╩╝╚╝
────────╔╝║
────────╚═╝`•websocket•`
**◇━━━━━━━━━━━━━━━━━◇**
**» Remarks     :** `{user}`
**» User Quota  :** `{pw} GB`
**» limit ip.   :** `{ip} IP`
**» port TLS     :** `443`
**» Port NTLS    :** `80`
**» Port GRPC    :** `443`
**» User ID     :** `{uuid}`
**» AlterId      :** `0`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `bug.com/trojan`
**» Path NLS     :** `bug.com/trojan`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `trojan-grpc`
**━━━━━━━━━━━━━━━━**
**» Link TLS   : **
`{b[0]}`
**━━━━━━━━━━━━━━━━**
**» Link WS    :** 
`{b[0].replace(" ","")}`
**━━━━━━━━━━━━━━━━**
**» Link GRPC  :** 
`{b[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━**
**openclass:**
http://{DOMAIN}:81/trojan-{user}.yaml
**◇━━━━━━━━━━━━━━━━━◇**
**Expired Until:** `{later}`
*» 🤖@candravpnz**
**◇━━━━━━━━━━━━━━━━━◇**
https://api.qrserver.com/v1/create-qr-code/?size=400x400&data={b[0]}
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-tr'))
async def cek_trojan(event):
	async def cek_trojan_(event):
		cmd = 'cek-tr'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

╔═╗─╔╗╔╗
║╔╬═╣╠╣╚╦╦╦═╦╦═╗╔═╦╗
║╚╣╩╣═╣╔╣╔╣╬╠╣╬╚╣║║║
╚═╩═╩╩╩═╩╝╚╦╝╠══╩╩═╝
───────────╚═╝
{z}

**Shows Logged In Users Trojan**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
@bot.on(events.NewMessage(pattern=r"(?:.trial-trojan|/trial3)$"))
@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
	async def trial_trojan_(event):


		cmd = f'printf "%s\n" "trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "2" "1" | addtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(1))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			remarks = re.search("#(.*)",b[0]).group(1)
			domain = re.search("@(.*?):",b[0]).group(1)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
╔════╗
║╔╗╔╗║───╔╗
╚╝║║╠╩╦══╬╬══╦═╗
──║║║╔╣╔╗╠╣╔╗║╔╗╗
──║║║║║╚╝║║╔╗║║║║
──╚╝╚╝╚══╣╠╝╚╩╝╚╝
────────╔╝║
────────╚═╝`•websocket•`
**◇━━━━━━━━━━━━━━━━━◇**
**» Remarks     :** `{remarks}`
**» User Quota  :** `1 GB`
**» Limit ip  :** `1 IP`
**» port TLS     :** `443`
**» Port NTLS    :** `80`
**» Port GRPC    :** `443`
**» User ID     :** `{uuid}`
**» AlterId      :** `0`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `bug.com/trojan`
**» Path NLS     :** `bug.com/trojan`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `trojan-grpc`
**━━━━━━━━━━━━━━━━**
**» Link TLS   : **
`{b[0]}`
**━━━━━━━━━━━━━━━━**
**» Link GRPC  :** 
`{b[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━**.
**openclass:**
http://{DOMAIN}:81/trojan-{remarks}.yaml
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `60 Minutes`
*» 🤖@candravpnz**
**◇━━━━━━━━━━━━━━━━━◇**
https://api.qrserver.com/v1/create-qr-code/?size=400x400&data={b[0]}
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-trojan'))
async def ren_trojan(event):
	async def ren_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "{user}" {exp} | renewtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Renewed {user} {exp}**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ren_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)



#CEK member VMESS
@bot.on(events.CallbackQuery(data=b'cek-membertr'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bash cek-mts'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Users from databases**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)


		
@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | deltr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline(" TRIAL TROJAN ","trial-trojan"),
Button.inline(" CREATE TROJAN ","create-trojan")],
[Button.inline(" CHECK TROJAN ","cek-tr"),
Button.inline(" DELETE TROJAN ","delete-trojan")],
[Button.inline(" RENEW TROJAN ","renew-trojan")],
[Button.inline(" CHECK MEMBER ","cek-membertr")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
╔════╗
║╔╗╔╗║───╔╗
╚╝║║╠╩╦══╬╬══╦═╗
──║║║╔╣╔╗╠╣╔╗║╔╗╗
──║║║║║╚╝║║╔╗║║║║
──╚╝╚╝╚══╣╠╝╚╩╝╚╝
────────╔╝║
────────╚═╝`•manager•`
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `TROJAN`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
