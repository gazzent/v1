from cybervpn import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("🔰SSH Menu🔰 ","ssh")],
[Button.inline("🔰Vmess MANAGER🔰 ","vmess"),
Button.inline("🔰Vless MANAGER🔰 ","vless")],
[Button.inline("🔰Trojan MANAGER🔰 ","trojan")],
[Button.inline("🖥️CHECK VPS INFO🖥️ ","info"),
Button.inline("⚙️OTHER SETTING⚙️","setting")],
[Button.url("🚻Tele Group🚻","https://t.me/candravpnz"),
Button.url("💵Order script?💵 ","https://wa.me/6281573872702")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Acces Denied", alert=True)
		except:
			await event.reply("Acces Denied")
	elif val == "true":
		msg = f"""
**━━━━━━━━━━━━━━━━**
╔═╗─╔╗────╔╗─╔╦═╦═╦╗
║╔╬╦╣╚╦═╦╦╣╚╦╝║╬║║║║
║╚╣║║╬║╩╣╔╩╗║╔╣╔╣║║║
╚═╬╗╠═╩═╩╝─╚═╝╚╝╚╩═╝
──╚═╝`•admin panel•`
**━━━━━━━━━━━━━━━━**
**» 🔰Version:** `v3.1.1`
**» 🔰channel:** `@candravpnz`
**» 🔰Bot by candravpnz **
**━━━━━━━━━━━━━━━━**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
