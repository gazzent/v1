
curl -sS "https://raw.githubusercontent.com/irawancandra6699/azg/main/dashboard.sh" | bash