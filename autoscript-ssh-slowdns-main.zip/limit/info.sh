clear
figlet -f 3d "CyberVPN Tunneling" | lolcat
cat /root/log-install.txt
echo "-----------------------------------------------------"
echo "                Credit Script By Candra irawan" | lolcat
echo "                   Author Script CyberVPN" | lolcat
echo "-----------------------------------------------------"
